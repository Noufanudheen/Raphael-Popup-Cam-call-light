# Raphael Popup Camera Call Light (KernelSu)

This module controls the pop-up camera LED on the raphael device and triggers it on incoming calls.

Features:
- incoming call trigger
- configurable blink speed
- custom pattern support
- mode rules: silent/vibrate/always
- Pixel/EvolutionX overlay integration option
- fallback WebGUI for non-Pixel ROMs

## Installation Guide

1. Copy module directory to `/data/adb/modules/raphael-popup-cam-light`.
2. Ensure permissions are correct:
   - `ksu -c "chmod -R 755 /data/adb/modules/raphael-popup-cam-light"`
3. Reboot device.
4. Confirm module is listed in Magisk/KSU module manager.
5. Start service (or reboot already starts):
   - `ksu -c "/data/adb/modules/raphael-popup-cam-light/service.sh"`
6. Open WebGUI in browser (device local): `http://127.0.0.1:8080`.

## Configuration

- `system/etc/popup_light.conf`
- `ENABLED=1`
- `RULE=always` (silent/vibrate/normal/always)
- `SPEED_MS=250`
- `PATTERN=150,150,150,150`

## Usage

- Set rule via WebGUI or config file.
- Place phone in mode Silent/Vibrate/Normal for rule testing.
- Make an incoming call to verify LED blink.

## Stopping

- `ksu -c "pkill -f raphael_popup_lightd.sh"`
- `ksu -c "pkill -f webgui_server.py"`

## Uninstall

1. `ksu -c "rm -rf /data/adb/modules/raphael-popup-cam-light"`
2. Reboot.
